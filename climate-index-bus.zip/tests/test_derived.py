from datetime import date

from climate_index_bus.derived import compute_degree_days, group_by_month, sum_degree_days
from climate_index_bus.schema import ClimateRecord


def _rec(variable, d, value):
    return ClimateRecord(
        source="noaa_ghcn",
        station_id="TEST0001",
        variable=variable,
        date=d,
        value=value,
        unit="degC",
    )


def test_compute_degree_days_hot_day():
    # avg temp = 30C, well above 18.3C baseline -> should be all CDD, zero HDD
    tmax = [_rec("TMAX", date(2024, 7, 1), 35.0)]
    tmin = [_rec("TMIN", date(2024, 7, 1), 25.0)]

    result = compute_degree_days(tmax, tmin)

    hdd = next(r for r in result if r.variable == "HDD")
    cdd = next(r for r in result if r.variable == "CDD")

    assert hdd.value == 0.0
    assert cdd.value == round(30.0 - 18.3, 3)


def test_compute_degree_days_cold_day():
    # avg temp = 0C, well below baseline -> should be all HDD, zero CDD
    tmax = [_rec("TMAX", date(2024, 1, 1), 2.0)]
    tmin = [_rec("TMIN", date(2024, 1, 1), -2.0)]

    result = compute_degree_days(tmax, tmin)

    hdd = next(r for r in result if r.variable == "HDD")
    cdd = next(r for r in result if r.variable == "CDD")

    assert cdd.value == 0.0
    assert hdd.value == round(18.3 - 0.0, 3)


def test_compute_degree_days_only_uses_common_dates():
    tmax = [_rec("TMAX", date(2024, 1, 1), 10.0), _rec("TMAX", date(2024, 1, 2), 10.0)]
    tmin = [_rec("TMIN", date(2024, 1, 1), 5.0)]  # missing day 2

    result = compute_degree_days(tmax, tmin)
    dates_present = {r.date for r in result}

    assert dates_present == {date(2024, 1, 1)}


def test_sum_and_group_by_month():
    records = [
        _rec("HDD", date(2024, 1, 1), 5.0),
        _rec("HDD", date(2024, 1, 2), 3.0),
        _rec("HDD", date(2024, 2, 1), 1.0),
    ]

    grouped = group_by_month(records)
    assert set(grouped.keys()) == {"2024-01", "2024-02"}
    assert sum_degree_days(grouped["2024-01"]) == 8.0
    assert sum_degree_days(grouped["2024-02"]) == 1.0
