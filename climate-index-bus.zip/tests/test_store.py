from datetime import date

from climate_index_bus.schema import ClimateRecord
from climate_index_bus.store import Store


def _rec(value, d=date(2024, 1, 1)):
    return ClimateRecord(
        source="noaa_ghcn",
        station_id="USW00023174",
        variable="TMAX",
        date=d,
        value=value,
        unit="degC",
    )


def test_upsert_and_query_roundtrip():
    store = Store(db_url="sqlite:///:memory:")
    written = store.upsert([_rec(25.0)])
    assert written == 1

    results = store.query(station_id="USW00023174", variable="TMAX")
    assert len(results) == 1
    assert results[0].value == 25.0


def test_upsert_is_idempotent():
    store = Store(db_url="sqlite:///:memory:")
    store.upsert([_rec(25.0)])
    written_again = store.upsert([_rec(25.0)])  # same natural key
    assert written_again == 0

    results = store.query(station_id="USW00023174")
    assert len(results) == 1


def test_query_filters_by_date_range():
    store = Store(db_url="sqlite:///:memory:")
    store.upsert(
        [
            _rec(10.0, d=date(2024, 1, 1)),
            _rec(20.0, d=date(2024, 6, 1)),
            _rec(30.0, d=date(2024, 12, 1)),
        ]
    )

    results = store.query(
        station_id="USW00023174", start=date(2024, 5, 1), end=date(2024, 7, 1)
    )
    assert len(results) == 1
    assert results[0].value == 20.0
