from datetime import date

from climate_index_bus.connectors.noaa import NoaaGhcnConnector


def _build_dly_line(station_id: str, year: int, month: int, element: str, day_values: dict[int, int]) -> str:
    """Build a single fixed-width .dly line for testing, matching NOAA's
    GHCN-Daily format: 11-char station id, 4-char year, 2-char month,
    4-char element, then 31 8-char day blocks (5-char value + 3 flag chars).
    Missing days are filled with -9999.
    """
    header = f"{station_id:<11}{year:04d}{month:02d}{element:<4}"
    blocks = []
    for day in range(1, 32):
        value = day_values.get(day, -9999)
        blocks.append(f"{value:>5}   ")  # value + mflag + qflag + sflag (blank = ok)
    return header + "".join(blocks)


def test_parses_known_values_and_skips_missing(monkeypatch):
    station_id = "USW00023174"
    line = _build_dly_line(station_id, 2024, 1, "TMAX", {1: 250, 15: 100})  # 25.0C, 10.0C

    connector = NoaaGhcnConnector()
    monkeypatch.setattr(connector, "_download", lambda sid: [line])

    records = connector.fetch(
        station_id=station_id,
        start=date(2024, 1, 1),
        end=date(2024, 1, 31),
        variables=["TMAX"],
    )

    by_day = {r.date.day: r.value for r in records}
    assert by_day[1] == 25.0
    assert by_day[15] == 10.0
    # days without values (-9999) should not appear at all
    assert 2 not in by_day
    assert len(records) == 2


def test_filters_by_variable(monkeypatch):
    station_id = "USW00023174"
    tmax_line = _build_dly_line(station_id, 2024, 1, "TMAX", {1: 200})
    prcp_line = _build_dly_line(station_id, 2024, 1, "PRCP", {1: 50})

    connector = NoaaGhcnConnector()
    monkeypatch.setattr(connector, "_download", lambda sid: [tmax_line, prcp_line])

    records = connector.fetch(
        station_id=station_id,
        start=date(2024, 1, 1),
        end=date(2024, 1, 31),
        variables=["PRCP"],
    )

    assert len(records) == 1
    assert records[0].variable == "PRCP"
    assert records[0].value == 5.0  # 50 tenths-of-mm -> 5.0mm
    assert records[0].unit == "mm"


def test_respects_date_range(monkeypatch):
    station_id = "USW00023174"
    line = _build_dly_line(station_id, 2024, 1, "TMAX", {1: 200, 20: 200})

    connector = NoaaGhcnConnector()
    monkeypatch.setattr(connector, "_download", lambda sid: [line])

    records = connector.fetch(
        station_id=station_id,
        start=date(2024, 1, 1),
        end=date(2024, 1, 5),
        variables=["TMAX"],
    )

    assert len(records) == 1
    assert records[0].date == date(2024, 1, 1)
