"""Every data source implements this interface. Adding a new source means
subclassing BaseConnector and implementing `fetch()` — nothing downstream
needs to change.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import date

from climate_index_bus.schema import ClimateRecord


class BaseConnector(ABC):
    """Contract every connector must satisfy."""

    #: short machine-readable name, e.g. "noaa_ghcn" — used as `ClimateRecord.source`
    source_name: str

    @abstractmethod
    def fetch(
        self,
        station_id: str,
        start: date,
        end: date,
        variables: list[str] | None = None,
    ) -> list[ClimateRecord]:
        """Fetch and normalize records for a station/grid-cell over a date range.

        Parameters
        ----------
        station_id: the source-specific identifier for the location.
        start / end: inclusive date range.
        variables: optional filter, e.g. ["TMAX", "TMIN"]. If None, return
            whatever the source provides by default.

        Returns
        -------
        list[ClimateRecord] — already normalized, ready to hand to the store.
        """
        raise NotImplementedError
