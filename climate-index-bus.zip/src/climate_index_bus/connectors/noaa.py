"""Connector for NOAA's Global Historical Climatology Network - Daily (GHCN-D).

No API key required — this reads directly from NOAA's public archive of
per-station .dly files:
    https://www.ncei.noaa.gov/pub/data/ghcn/daily/all/{station_id}.dly

This is the same underlying station network CME's weather futures settle
against, so station IDs for CME's benchmark cities are listed in
`climate_index_bus.stations`.

.dly format reference (fixed-width text, one line per station-year-month-element):
    cols 1-11   station ID
    cols 12-15  year
    cols 16-17  month
    cols 18-21  element (e.g. TMAX, TMIN, PRCP)
    then 31 repeating 8-char blocks, one per day of month:
        5 chars value (tenths of a unit; -9999 = missing)
        1 char  mflag (measurement flag)
        1 char  qflag (quality flag)
        1 char  sflag (source flag)

TMAX/TMIN are in tenths of degrees C. PRCP is in tenths of mm.
"""

from __future__ import annotations

import calendar
import urllib.error
import urllib.request
from datetime import date

from climate_index_bus.connectors.base import BaseConnector
from climate_index_bus.schema import ClimateRecord

NOAA_ARCHIVE_URL = "https://www.ncei.noaa.gov/pub/data/ghcn/daily/all/{station_id}.dly"

# Tenths-of-a-unit -> real unit, and the resulting unit label, per element.
_ELEMENT_UNITS = {
    "TMAX": ("degC", 0.1),
    "TMIN": ("degC", 0.1),
    "TAVG": ("degC", 0.1),
    "PRCP": ("mm", 0.1),
    "SNOW": ("mm", 1.0),
}

_MISSING = -9999


class NoaaGhcnConnector(BaseConnector):
    source_name = "noaa_ghcn"

    def __init__(self, timeout_s: int = 30):
        self.timeout_s = timeout_s

    def fetch(
        self,
        station_id: str,
        start: date,
        end: date,
        variables: list[str] | None = None,
    ) -> list[ClimateRecord]:
        wanted = set(variables) if variables else set(_ELEMENT_UNITS)
        raw_lines = self._download(station_id)
        records: list[ClimateRecord] = []

        for line in raw_lines:
            if len(line) < 21:
                continue
            element = line[17:21].strip()
            if element not in wanted:
                continue

            year = int(line[11:15])
            month = int(line[15:17])
            days_in_month = calendar.monthrange(year, month)[1]

            unit, scale = _ELEMENT_UNITS.get(element, ("unknown", 1.0))

            for day in range(1, days_in_month + 1):
                obs_date = date(year, month, day)
                if not (start <= obs_date <= end):
                    continue

                block_start = 21 + (day - 1) * 8
                value_str = line[block_start : block_start + 5]
                try:
                    raw_value = int(value_str)
                except ValueError:
                    continue
                if raw_value == _MISSING:
                    continue

                qflag = line[block_start + 6 : block_start + 7].strip()

                records.append(
                    ClimateRecord(
                        source=self.source_name,
                        station_id=station_id,
                        variable=element,
                        date=obs_date,
                        value=round(raw_value * scale, 3),
                        unit=unit,
                        confidence="flagged" if qflag else "ok",
                    )
                )

        return records

    def _download(self, station_id: str) -> list[str]:
        url = NOAA_ARCHIVE_URL.format(station_id=station_id)
        try:
            with urllib.request.urlopen(url, timeout=self.timeout_s) as resp:
                text = resp.read().decode("utf-8", errors="replace")
        except urllib.error.HTTPError as e:
            raise ValueError(
                f"NOAA archive returned {e.code} for station '{station_id}'. "
                "Check the station ID (see climate_index_bus.stations)."
            ) from e
        return text.splitlines()
