"""Stub connector for ERA5 reanalysis data via the Copernicus Climate Data
Store (CDS).

ERA5 is the highest-value connector to add next: it provides gridded,
globally-consistent data even where no station exists, which matters for
regions like the Colorado River Basin or Ogallala Aquifer states that have
no CME weather product and sparse station coverage.

Not implemented yet because it requires:
  1. A free CDS API key (https://cds.climate.copernicus.eu/) and the `cdsapi`
     package.
  2. Downloading NetCDF/GRIB grids and extracting the nearest grid cell to a
     requested lat/lon (station_id here should be a "lat,lon" pair or a named
     grid-cell alias, not a station code).
  3. Async handling — CDS requests are queued, not instant, so `fetch()` will
     need to poll or this connector will need an async variant.

To implement: mirror the shape of NoaaGhcnConnector.fetch(), using `cdsapi`
to request the `reanalysis-era5-single-levels` dataset for 2m temperature /
total precipitation, then normalize into ClimateRecord the same way.
"""

from __future__ import annotations

from datetime import date

from climate_index_bus.connectors.base import BaseConnector
from climate_index_bus.schema import ClimateRecord


class Era5Connector(BaseConnector):
    source_name = "era5"

    def fetch(
        self,
        station_id: str,
        start: date,
        end: date,
        variables: list[str] | None = None,
    ) -> list[ClimateRecord]:
        raise NotImplementedError(
            "ERA5 connector is a stub. Needs a CDS API key and the `cdsapi` "
            "package. See module docstring for the implementation plan. "
            "Contributions welcome."
        )
