"""Normalized record schema. Every connector, regardless of upstream source,
returns data in this shape so downstream consumers (pricing libraries,
basis-risk tools, index builders) never need to know where the data came from.
"""

from __future__ import annotations

from datetime import date
from typing import Optional

from pydantic import BaseModel, Field


class ClimateRecord(BaseModel):
    """A single observation: one variable, one location, one day."""

    source: str = Field(..., description="Origin system, e.g. 'noaa_ghcn', 'era5', 'chirps'")
    station_id: str = Field(..., description="Station or grid-cell identifier")
    variable: str = Field(..., description="e.g. 'TMAX', 'TMIN', 'PRCP', 'HDD', 'CDD'")
    date: date
    value: float
    unit: str = Field(..., description="e.g. 'degC', 'mm', 'degree_days'")
    lat: Optional[float] = None
    lon: Optional[float] = None
    confidence: Optional[str] = Field(
        default=None, description="Source-reported quality flag, if any"
    )

    class Config:
        frozen = True


class Station(BaseModel):
    """Metadata for a station or grid-cell reference point."""

    station_id: str
    name: str
    source: str
    lat: float
    lon: float
    elevation_m: Optional[float] = None
    country: Optional[str] = None
    notes: Optional[str] = None
