"""CLI entry point.

Usage:
    python -m climate_index_bus.cli ingest noaa --station USW00023174 --start 2024-01-01 --end 2024-12-31
    python -m climate_index_bus.cli list-stations
"""

from __future__ import annotations

import argparse
from datetime import date

from climate_index_bus.connectors.noaa import NoaaGhcnConnector
from climate_index_bus.stations import BENCHMARK_STATIONS
from climate_index_bus.store import Store


def _parse_date(s: str) -> date:
    return date.fromisoformat(s)


def cmd_ingest_noaa(args: argparse.Namespace) -> None:
    connector = NoaaGhcnConnector()
    store = Store()

    print(f"Fetching {args.station} from NOAA GHCN-Daily archive...")
    records = connector.fetch(
        station_id=args.station,
        start=_parse_date(args.start),
        end=_parse_date(args.end),
        variables=args.variables.split(",") if args.variables else None,
    )
    print(f"Parsed {len(records)} records. Writing to store...")
    written = store.upsert(records)
    print(f"Done. {written} new rows written ({len(records) - written} already existed).")


def cmd_list_stations(args: argparse.Namespace) -> None:
    for s in BENCHMARK_STATIONS:
        print(f"{s.station_id}\t{s.name}\t({s.lat}, {s.lon})\t{s.notes or ''}")


def main() -> None:
    parser = argparse.ArgumentParser(prog="climate_index_bus")
    subparsers = parser.add_subparsers(dest="command", required=True)

    ingest_parser = subparsers.add_parser("ingest", help="Ingest data from a source")
    ingest_subparsers = ingest_parser.add_subparsers(dest="source", required=True)

    noaa_parser = ingest_subparsers.add_parser("noaa", help="Ingest from NOAA GHCN-Daily")
    noaa_parser.add_argument("--station", required=True, help="NOAA GHCN station ID, e.g. USW00023174")
    noaa_parser.add_argument("--start", required=True, help="YYYY-MM-DD")
    noaa_parser.add_argument("--end", required=True, help="YYYY-MM-DD")
    noaa_parser.add_argument(
        "--variables", required=False, default=None, help="Comma-separated, e.g. TMAX,TMIN,PRCP"
    )
    noaa_parser.set_defaults(func=cmd_ingest_noaa)

    list_stations_parser = subparsers.add_parser(
        "list-stations", help="List benchmark stations bundled with this project"
    )
    list_stations_parser.set_defaults(func=cmd_list_stations)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
