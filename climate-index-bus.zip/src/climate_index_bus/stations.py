"""Starter list of benchmark stations.

Mapping CME's benchmark weather-futures cities to their NOAA GHCN-Daily
station IDs, so outputs from this project are directly comparable/backtestable
against real CME weather contract settlements. Not exhaustive — CME lists ~18
US/European cities; PRs adding the rest (and their European/Canadian
equivalents) are welcome.
"""

from __future__ import annotations

from climate_index_bus.schema import Station

BENCHMARK_STATIONS: list[Station] = [
    Station(
        station_id="USW00094846",
        name="Chicago O'Hare Intl",
        source="noaa_ghcn",
        lat=41.9786,
        lon=-87.9048,
        country="US",
        notes="CME benchmark city (Chicago)",
    ),
    Station(
        station_id="USW00014732",
        name="New York LaGuardia",
        source="noaa_ghcn",
        lat=40.7794,
        lon=-73.8803,
        country="US",
        notes="CME benchmark city (New York)",
    ),
    Station(
        station_id="USW00023174",
        name="Los Angeles Intl Airport",
        source="noaa_ghcn",
        lat=33.9381,
        lon=-118.3889,
        country="US",
        notes="CME benchmark city (Los Angeles); also nearest major station to CA water-index regions",
    ),
    Station(
        station_id="USW00013874",
        name="Atlanta Hartsfield-Jackson Intl",
        source="noaa_ghcn",
        lat=33.6301,
        lon=-84.4418,
        country="US",
        notes="CME benchmark city (Atlanta)",
    ),
    Station(
        station_id="USW00003017",
        name="Denver Intl Airport",
        source="noaa_ghcn",
        lat=39.8466,
        lon=-104.6562,
        country="US",
        notes="CME benchmark city (Denver); also relevant to Colorado River Basin water risk",
    ),
    Station(
        station_id="USW00012960",
        name="Houston Intercontinental Airport",
        source="noaa_ghcn",
        lat=29.9792,
        lon=-95.3603,
        country="US",
        notes="CME benchmark city (Houston)",
    ),
    Station(
        station_id="USW00023234",
        name="San Francisco Intl Airport",
        source="noaa_ghcn",
        lat=37.6197,
        lon=-122.3647,
        country="US",
        notes="CME benchmark city (Sacramento proxy); relevant to CA water-index regions",
    ),
    Station(
        station_id="USW00013881",
        name="Raleigh-Durham Intl Airport",
        source="noaa_ghcn",
        lat=35.8776,
        lon=-78.7875,
        country="US",
        notes="CME benchmark city (Raleigh)",
    ),
]


def get_station(station_id: str) -> Station | None:
    for s in BENCHMARK_STATIONS:
        if s.station_id == station_id:
            return s
    return None
