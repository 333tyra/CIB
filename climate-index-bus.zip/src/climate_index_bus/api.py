"""Query API. Run with:

    uvicorn climate_index_bus.api:app --reload
"""

from __future__ import annotations

from datetime import date

from fastapi import FastAPI, HTTPException, Query

from climate_index_bus.derived import compute_degree_days, group_by_month, sum_degree_days
from climate_index_bus.schema import ClimateRecord, Station
from climate_index_bus.stations import BENCHMARK_STATIONS
from climate_index_bus.store import Store

app = FastAPI(
    title="climate-index-bus",
    description="Unified query layer over weather/water climate data sources.",
    version="0.1.0",
)
store = Store()


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/stations", response_model=list[Station])
def list_stations():
    return BENCHMARK_STATIONS


@app.get("/records", response_model=list[ClimateRecord])
def get_records(
    station_id: str | None = None,
    variable: str | None = None,
    source: str | None = None,
    start: date | None = None,
    end: date | None = None,
):
    return store.query(
        station_id=station_id, variable=variable, source=source, start=start, end=end
    )


@app.get("/degree-days", response_model=list[ClimateRecord])
def get_degree_days(
    station_id: str = Query(..., description="Station ID to compute HDD/CDD for"),
    start: date = Query(...),
    end: date = Query(...),
    source: str = Query("noaa_ghcn"),
):
    """Compute daily HDD/CDD on the fly from stored TMAX/TMIN — no separate
    ingestion needed, matches how CME's own contracts are settled.
    """
    tmax = store.query(station_id=station_id, variable="TMAX", source=source, start=start, end=end)
    tmin = store.query(station_id=station_id, variable="TMIN", source=source, start=start, end=end)
    if not tmax or not tmin:
        raise HTTPException(
            status_code=404,
            detail=(
                f"No TMAX/TMIN data found for station_id={station_id} in range "
                f"{start}..{end}. Ingest it first: "
                f"`python -m climate_index_bus.cli ingest noaa --station {station_id} "
                f"--start {start} --end {end}`"
            ),
        )
    return compute_degree_days(tmax, tmin)


@app.get("/degree-days/summary")
def get_degree_days_summary(
    station_id: str = Query(...),
    start: date = Query(...),
    end: date = Query(...),
    source: str = Query("noaa_ghcn"),
):
    """Monthly totals — this is the shape CME's monthly HDD/CDD futures
    actually settle against.
    """
    dd = get_degree_days(station_id=station_id, start=start, end=end, source=source)
    hdd = [r for r in dd if r.variable == "HDD"]
    cdd = [r for r in dd if r.variable == "CDD"]

    monthly_hdd = {k: sum_degree_days(v) for k, v in group_by_month(hdd).items()}
    monthly_cdd = {k: sum_degree_days(v) for k, v in group_by_month(cdd).items()}

    return {
        "station_id": station_id,
        "range": {"start": start, "end": end},
        "monthly_hdd_total": monthly_hdd,
        "monthly_cdd_total": monthly_cdd,
        "period_hdd_total": sum_degree_days(hdd),
        "period_cdd_total": sum_degree_days(cdd),
    }
