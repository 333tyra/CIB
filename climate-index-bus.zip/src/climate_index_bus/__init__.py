"""climate-index-bus: a unified data layer for weather- and water-index instruments."""

__version__ = "0.1.0"
