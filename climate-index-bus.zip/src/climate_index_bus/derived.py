"""Derived variables computed on top of stored raw observations.

CME's HDD/CDD contracts settle against degree days computed from daily
average temperature relative to a 65degF (18.3degC) baseline. This module
computes them from stored TMAX/TMIN records rather than requiring a separate
ingestion pipeline.
"""

from __future__ import annotations

from collections import defaultdict
from datetime import date

from climate_index_bus.schema import ClimateRecord

BASELINE_C = 18.3  # 65 degrees F, the standard HDD/CDD reference temperature


def compute_degree_days(
    tmax_records: list[ClimateRecord],
    tmin_records: list[ClimateRecord],
    baseline_c: float = BASELINE_C,
) -> list[ClimateRecord]:
    """Compute daily HDD and CDD from paired TMAX/TMIN records.

    Daily avg temp = (TMAX + TMIN) / 2
    HDD = max(0, baseline - avg_temp)
    CDD = max(0, avg_temp - baseline)

    Only dates present in both TMAX and TMIN are computed.
    """
    tmax_by_date: dict[date, ClimateRecord] = {r.date: r for r in tmax_records}
    tmin_by_date: dict[date, ClimateRecord] = {r.date: r for r in tmin_records}

    common_dates = sorted(set(tmax_by_date) & set(tmin_by_date))
    out: list[ClimateRecord] = []

    for d in common_dates:
        tmax = tmax_by_date[d]
        tmin = tmin_by_date[d]
        avg_temp = (tmax.value + tmin.value) / 2
        hdd = max(0.0, baseline_c - avg_temp)
        cdd = max(0.0, avg_temp - baseline_c)

        common_kwargs = dict(
            source=tmax.source,
            station_id=tmax.station_id,
            date=d,
            unit="degree_days",
            confidence=tmax.confidence,
        )
        out.append(ClimateRecord(variable="HDD", value=round(hdd, 3), **common_kwargs))
        out.append(ClimateRecord(variable="CDD", value=round(cdd, 3), **common_kwargs))

    return out


def sum_degree_days(records: list[ClimateRecord]) -> float:
    """Sum degree days over a period — this is what CME's monthly/seasonal
    HDD/CDD futures actually settle against (total, not average).
    """
    return round(sum(r.value for r in records), 3)


def group_by_month(records: list[ClimateRecord]) -> dict[str, list[ClimateRecord]]:
    grouped: dict[str, list[ClimateRecord]] = defaultdict(list)
    for r in records:
        key = f"{r.date.year:04d}-{r.date.month:02d}"
        grouped[key].append(r)
    return dict(grouped)
