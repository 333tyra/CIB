"""Storage layer. Defaults to a local SQLite file for easy dev/testing;
point DATABASE_URL at Postgres (ideally with the TimescaleDB extension) for
production-scale ingestion.
"""

from __future__ import annotations

import os
from datetime import date

from sqlalchemy import Column, Date, Float, Index, String, create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from climate_index_bus.schema import ClimateRecord

DEFAULT_DB_URL = "sqlite:///./climate_index_bus.db"


class Base(DeclarativeBase):
    pass


class ClimateRecordRow(Base):
    __tablename__ = "climate_records"

    # composite natural key: a given source/station/variable/date is unique
    source = Column(String, primary_key=True)
    station_id = Column(String, primary_key=True)
    variable = Column(String, primary_key=True)
    date = Column(Date, primary_key=True)

    value = Column(Float, nullable=False)
    unit = Column(String, nullable=False)
    lat = Column(Float, nullable=True)
    lon = Column(Float, nullable=True)
    confidence = Column(String, nullable=True)

    __table_args__ = (
        Index("ix_station_variable_date", "station_id", "variable", "date"),
    )


class Store:
    def __init__(self, db_url: str | None = None):
        self.db_url = db_url or os.environ.get("DATABASE_URL", DEFAULT_DB_URL)
        self.engine = create_engine(self.db_url)
        Base.metadata.create_all(self.engine)
        self._session_factory = sessionmaker(bind=self.engine)

    def session(self) -> Session:
        return self._session_factory()

    def upsert(self, records: list[ClimateRecord]) -> int:
        """Insert records, skipping ones that already exist (idempotent
        re-ingestion). Returns count of rows actually written.
        """
        written = 0
        with self.session() as session:
            for r in records:
                exists = (
                    session.query(ClimateRecordRow)
                    .filter_by(
                        source=r.source,
                        station_id=r.station_id,
                        variable=r.variable,
                        date=r.date,
                    )
                    .first()
                )
                if exists:
                    continue
                session.add(
                    ClimateRecordRow(
                        source=r.source,
                        station_id=r.station_id,
                        variable=r.variable,
                        date=r.date,
                        value=r.value,
                        unit=r.unit,
                        lat=r.lat,
                        lon=r.lon,
                        confidence=r.confidence,
                    )
                )
                written += 1
            session.commit()
        return written

    def query(
        self,
        station_id: str | None = None,
        variable: str | None = None,
        source: str | None = None,
        start: date | None = None,
        end: date | None = None,
    ) -> list[ClimateRecord]:
        with self.session() as session:
            q = session.query(ClimateRecordRow)
            if station_id:
                q = q.filter(ClimateRecordRow.station_id == station_id)
            if variable:
                q = q.filter(ClimateRecordRow.variable == variable)
            if source:
                q = q.filter(ClimateRecordRow.source == source)
            if start:
                q = q.filter(ClimateRecordRow.date >= start)
            if end:
                q = q.filter(ClimateRecordRow.date <= end)
            rows = q.order_by(ClimateRecordRow.date).all()

        return [
            ClimateRecord(
                source=row.source,
                station_id=row.station_id,
                variable=row.variable,
                date=row.date,
                value=row.value,
                unit=row.unit,
                lat=row.lat,
                lon=row.lon,
                confidence=row.confidence,
            )
            for row in rows
        ]
